<a name="1.4.2"></a>
## [1.4.2](https://github.com/hbi99/defiant.js/compare/v1.4.0...v1.4.2) (2017-04-26)




<a name="1.4.1"></a>
## [1.4.1](https://github.com/hbi99/defiant.js/compare/v1.3.9...v1.4.1) (2016-07-24)




<a name="1.3.9"></a>
## [1.3.9](https://github.com/hbi99/defiant.js/compare/v1.3.8...v1.3.9) (2016-05-07)




<a name="1.3.8"></a>
## [1.3.8](https://github.com/hbi99/defiant.js/compare/1.3.7...v1.3.8) (2016-01-31)




